D=print
import base64 as F
from Crypto.Cipher import AES as A
from Crypto.Hash import SHA256 as G
B='QJK2fM9trrIcA7VcNff51AYnhJjfieqVyIG7U5QVav7aCAGLhfomqhoxOdwoQ/GCwYmYHcqQtyq67sL0nJQ23/ugk+/MI0OUwrTrxUceTGhvEtJZNNcjI5RMcDpRLd4Lb/6hhn5mKgUxm0ARrrsU8NEkRXHFjsKOSLUuVV1ZxCY='
def C(key,source,decode=True):
	D=key;B=source
	if decode:B=F.b64decode(B.encode('latin-1'))
	D=G.new(D).digest();H=B[:A.block_size];I=A.new(D,A.MODE_CBC,H);E=I.decrypt(B[A.block_size:]);C=E[-1]
	if E[-C:]!=bytes([C])*C:raise ValueError
	return E[:-C]
try:D(C(str.encode(input('Enter key: ')),B).decode('utf-8'));
except:D('Wrong. Try again.')